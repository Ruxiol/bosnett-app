export default interface ImagesId {
    fileIds: string[];
}