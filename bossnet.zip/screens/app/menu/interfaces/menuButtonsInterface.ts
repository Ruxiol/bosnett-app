export default interface menuButtonsInterface {
    icon: JSX.Element;
    text: string;
    screenName?: string;
}