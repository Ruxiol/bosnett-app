export default interface footerIconsInterface {
    icon: JSX.Element;
    text: string;
}