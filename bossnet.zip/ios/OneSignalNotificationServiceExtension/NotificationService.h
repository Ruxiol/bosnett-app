//  NotificationService.h
//  OneSignalNotificationServiceExtension

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
