export default interface CommentRequestData {
    comment: string;
    feedPostId: string;
}