export default interface SubCommentRequestData {
    comment: string;
    commentId: string;
}