export default interface SuccesModalProps {
    successText: string;
}