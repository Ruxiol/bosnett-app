export default interface OptionsInterface {
    icon: JSX.Element;
    title: string;
    description: string;
}