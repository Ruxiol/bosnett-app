export default interface PostVisibilityModalProps {
    isModalVisible: boolean;
    setIsModalVisible: (value: boolean) => void;
    setSelectedOption: (value: string) => void;
}