export default interface ErrorStateInterface {
    message: string;
}