export default interface newsFeedItemPayload {
    postId: string;
    commentsCount: number;
}
