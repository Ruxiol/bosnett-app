export default interface ImageFullScreenModalPayload {
    isVisible: boolean;
    uris?: string[];
    startIndex?: number;
}