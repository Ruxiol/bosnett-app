export default interface ImageFullScreenModalStateInterface {
    isVisible: boolean;
    imageUris?: string[];
    startIndex?: number;
}