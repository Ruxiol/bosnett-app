const config = {
    assets: ['./assets/fonts/'],
};

export default config;