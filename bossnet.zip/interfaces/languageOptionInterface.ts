export default interface LanguageOptionInterface {
    label: string;
    value: string;
} 