export default interface SignInParamsInterface {
    prefillUsername?: string;
    prefillPassword?: string;
}