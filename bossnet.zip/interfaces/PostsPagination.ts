export default interface PostsPagination {
    count: number;
    pageSize: number,
    currentPage: number,
    totalPages: number
}