export default interface UserValuePairs {
    name: string;
    value: string;
}