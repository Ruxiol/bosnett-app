export default interface IFriendsData {
    userId: string,
    email: string,
    firstName: string,
    lastName: string,
    userName: string,
    profileImage: string,
    status: string,
    _id: string
}