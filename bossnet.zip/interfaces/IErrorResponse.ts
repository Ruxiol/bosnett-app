export default interface IErrorResponse {
    status: boolean;
    message: string;
}