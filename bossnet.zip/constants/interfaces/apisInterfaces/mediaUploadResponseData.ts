export default interface MediaUploadResponseData {
    userId: string;
    path: string;
    fileType: string;
    _id: string;
    createdAt: string;
    updatedAt: string;
    __v: number;
}