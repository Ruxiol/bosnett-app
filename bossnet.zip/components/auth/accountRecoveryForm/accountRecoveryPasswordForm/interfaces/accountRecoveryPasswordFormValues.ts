export default interface AccountRecoveryPasswordFormValues {
    password: string;
    confirmPassword: string;
}