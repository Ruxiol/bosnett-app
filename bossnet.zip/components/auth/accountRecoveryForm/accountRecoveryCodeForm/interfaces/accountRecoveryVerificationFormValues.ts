export default interface AccountRecoveryVerificationFormValues {
    otp_code: string;
}