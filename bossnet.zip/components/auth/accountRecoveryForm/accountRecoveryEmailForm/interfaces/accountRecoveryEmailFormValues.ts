export default interface AccountRecoveryEmailFormValues {
    email: string;
}