export default interface AccountRecoveryFormValuesInterface {
    email: string;
    otp_code: string;
    password: string;
}