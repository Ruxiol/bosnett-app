export default interface SignUpDobValuesInterface {
    dayOfBirth: Date;
    agreeToTerms: boolean;
}