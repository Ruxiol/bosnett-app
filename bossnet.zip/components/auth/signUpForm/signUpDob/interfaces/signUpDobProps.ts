import { FormikProps } from "formik";

import SignUpDobValuesInterface from "./signUpDobValuesInterface";

export default interface SignUpDobProps {
    formik: FormikProps<SignUpDobValuesInterface>;
}