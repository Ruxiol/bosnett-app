export default interface SignUpResponseInterface {
    email: string;
    firstName: string;
    lastName: string;
    userName: string;
    dayOfBirth: string;
    profileImage: string;
    token: string;
}