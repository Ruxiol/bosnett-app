export default interface SignUpPasswordValuesInterface {
    password: string;
    confirmPassword: string;
}