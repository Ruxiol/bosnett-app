import { FormikProps } from 'formik';

import SignUpNameValuesInterface from './signUpNameValuesinterface';

export default interface SignUpNameProps {
    formik: FormikProps<SignUpNameValuesInterface>;
}