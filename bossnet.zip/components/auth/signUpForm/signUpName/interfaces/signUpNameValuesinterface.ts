export default interface SignUpNameValuesInterface {
    firstName: string;
    lastName: string;
    userName: string;
}