import ImageInterface from "../../../../common/interfaces/imageInterface";

export default interface SignUpProfilePictureValuesInterface {
    image: ImageInterface;
}