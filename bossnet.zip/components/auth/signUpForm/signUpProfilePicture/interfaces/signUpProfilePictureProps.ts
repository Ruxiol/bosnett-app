import { FormikProps } from "formik";

import SignUpProfilePictureValuesInterface from "./signUpProfilePictureValuesInterface";

export default interface SignUpProfilePictureProps {
    formik: FormikProps<SignUpProfilePictureValuesInterface>;
}