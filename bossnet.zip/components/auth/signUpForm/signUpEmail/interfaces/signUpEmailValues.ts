export default interface SignUpEmailValuesInterface {
    email: string;
    confirmEmail: string;
}