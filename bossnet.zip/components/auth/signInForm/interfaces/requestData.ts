export default interface RequestData {
    email_or_username: string;
    password: string;
    selectedLanguage?: string | undefined;
}