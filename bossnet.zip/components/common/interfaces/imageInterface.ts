export default interface ImageInterface {
    uri: string | undefined;
    type: string | undefined;
    filename: string | undefined;
}