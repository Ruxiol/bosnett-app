export default interface FooterButtonsInterface {
    icon: JSX.Element;
    activeIcon: JSX.Element;
    text?: string;
    screenName: string;
}