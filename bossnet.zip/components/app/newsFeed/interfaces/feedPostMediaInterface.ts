export default interface FeedPOstMediaInterface {
    _id: string;
    userId: string;
    path: string;
    fileType: string;
    createdAt: string;
    updatedAt: string;
    __v: number;
}