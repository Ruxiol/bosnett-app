export default interface AppHeaderProps {
    headerText?: string;
    chatHeader?: boolean;
    icon?: boolean;
}