import { ReactNode } from "react";

export default interface MainWrapperProps {
    children: ReactNode;
    isFooter?: boolean;
}