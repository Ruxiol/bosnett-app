export default interface TabHeading {
    title: string
}