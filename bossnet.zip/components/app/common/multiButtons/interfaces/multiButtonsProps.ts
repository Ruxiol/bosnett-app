import ButtonsInterface from "./buttonsInterface";

export default interface MultiButtonsProps {
    buttons: ButtonsInterface[];
}