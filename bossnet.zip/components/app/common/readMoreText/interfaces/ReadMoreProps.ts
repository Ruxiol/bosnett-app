export default interface ReadMoreProps {
    text: string;
    numberOfLines?: number;
}