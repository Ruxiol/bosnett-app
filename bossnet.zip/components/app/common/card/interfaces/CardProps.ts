import CardItem from "./CardItem";

export default interface CardProps {
    cardItem: CardItem[];
}