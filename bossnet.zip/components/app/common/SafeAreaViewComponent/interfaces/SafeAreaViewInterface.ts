import { ReactNode } from "react";

export default interface SafeAreaViewInterface {
    children: ReactNode;
}